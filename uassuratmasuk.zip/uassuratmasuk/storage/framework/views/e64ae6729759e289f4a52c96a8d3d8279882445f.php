


<div class="p2">
    <div class="form-group mb-3">
        <input type="text" name="judul" id="judul" class="form-control " placeholder="Judul..." required value="<?php echo e($Surat->judul); ?>" autocomplete="off">
    </div>
    <div class="form-group mb-3">
        <input type="date" name="tanggal" id="tanggal" class="form-control "placeholder="Tanggal Surat..." required value="<?php echo e($Surat->tanggal); ?>" autocomplete="off">
    </div>

    <div class="form-group mb-3">
        <input type="text" name="perihal" id="perihal" class="form-control " placeholder="Perihal..." required value="<?php echo e($Surat->perihal); ?>" autocomplete="off">
    </div>

    <div class="form-group">
        <input type="text" class="form-control" name="alamat" id="alamat" placeholder="Alamat..." required value="<?php echo e($Surat->alamat); ?>" autocomplete="off"></textarea>
      </div>
      

    <div class="form-group mt-5">
        <button class="btn btn-primary" onclick="update(<?php echo e($Surat->id); ?>)">Update Surat</button>
        </div>
    </div><?php /**PATH D:\uassuratmasuk\resources\views/update.blade.php ENDPATH**/ ?>