<table class="table">
    <thead>
        <tr>
            <th>No</th>
            <th>Judul Surat</th>
            <th>Tanggal Surat</th>
            <th>Perihal</th>
            <th>Alamat</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody> 
        
        <?php $__currentLoopData = $Surat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($surat->judul); ?></td>
              <td><?php echo e($surat->tanggal); ?></td>
              <td><?php echo e($surat->perihal); ?></td>
              <td><?php echo e($surat->alamat); ?></td>
            <td>
                <button class="btn btn-success text-bg-success" onclick="show(<?php echo e($surat->id); ?>)">Update</button>
                <button class="btn btn-danger text-bg-danger" onclick="destroy(<?php echo e($surat->id); ?>)">Delete</button>    </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\uassuratmasuk\resources\views/read.blade.php ENDPATH**/ ?>