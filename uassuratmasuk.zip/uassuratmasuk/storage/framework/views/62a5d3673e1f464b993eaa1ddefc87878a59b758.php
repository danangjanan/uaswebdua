<div class="p2">
    <div class="form-group mb-3">
        <input type="date" name="tanggal" id="tanggal" class="form-control "placeholder="Tanggal Surat..." required autocomplete="off">
    </div>

    <div class="form-group mb-3">
        <input type="text" name="judul" id="judul" class="form-control " placeholder="Judul..." required autocomplete="off">
    </div>
    
    <div class="form-group mb-3">
        <input type="text" name="perihal" id="perihal" class="form-control " placeholder="Perihal..." required autocomplete="off">
    </div>
    
    <div class="form-group mb-3">
        <textarea type="text" class="form-control" name="alamat" id="alamat" placeholder="Alamat..." required autocomplete="off"></textarea>
      </div>
      


    <button class="btn btn-primary" onclick="store()">Tambah Data</button>
</div><?php /**PATH D:\uassuratmasuk\resources\views/create.blade.php ENDPATH**/ ?>